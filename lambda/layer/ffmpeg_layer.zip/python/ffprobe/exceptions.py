class FFProbeError(Exception):
    pass
